package grails.plugin.jesque

enum JesqueDelayedJobThreadState {
    New,
    Running,
    Stopped
}
